import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";

export const DashboardLayout = () => {

  return (

    <div className="dashboard-container">

      <Sidebar />

      <main className="dashboard-content">
        <Outlet />
      </main>

    </div>

  );
};